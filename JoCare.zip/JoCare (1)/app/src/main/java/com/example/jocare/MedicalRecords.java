package com.example.jocare;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MedicalRecords extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_medical_records);
    }
}